//
//  ViewController.swift
//  openLibrary
//
//  Created by Javier Oñate on 11/19/15.
//  Copyright © 2015 Javier Oñate. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var isbnNumero: UITextField!
    
    @IBOutlet weak var resultadosText: UITextView!
    
    @IBOutlet weak var error: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func borrar(sender: UIButton) {
        self.isbnNumero.text = ""
        self.resultadosText.text = ""
        self.error.text = ""
    }

    @IBAction func buscar(sender: UIButton) {
            buscarSincrono()
    }
    
    func buscarSincrono()
    {
        let isbn = self.isbnNumero.text! as String
        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:\(isbn)"
        let url = NSURL(string: urls)
        if let datos:NSData? = NSData(contentsOfURL: url!){
            self.error.text = ""
            let texto = NSString(data:datos!, encoding:NSUTF8StringEncoding)
            if texto=="{}"{
                self.error.text = "No se encontro el número de ISBN indicado."
                self.resultadosText.text = ""
            }else{
                self.error.text = ""
                self.resultadosText.text = texto as! String
            }
        }else{
           self.error.text = "No se encontro la direccion selecionada. Por favor intnente despues."
        }
    }
    
}

